# SMTP Setup for Ethical Phishing Simulation Platform

Use any of the following tools to safely test email functionality:

- **MailHog**: Docker run -d -p 1025:1025 -p 8025:8025 mailhog/mailhog
- **smtp4dev**: Local test SMTP with web UI
- **Papercut**: Windows SMTP viewer
- **Mailtrap**: Cloud-based safe test inbox

### Flask-Mail Config (for MailHog)
MAIL_SERVER = 'localhost'
MAIL_PORT = 1025
MAIL_USE_TLS = False
MAIL_USE_SSL = False
MAIL_USERNAME = None
MAIL_PASSWORD = None
MAIL_DEFAULT_SENDER = 'no-reply@example.com'
