# Security & Ethics

## Responsible use
This repository contains code for an **Ethical Phishing Simulation Platform** intended only for defensive and educational use. DO NOT use this project to send unconsented phishing emails or to attempt to steal credentials.

## Usage requirements
- Only run campaigns against consenting users, test accounts, or an isolated lab environment.
- Do not collect passwords or sensitive user input. This project intentionally does not record credentials.
- Protect any stored email addresses or tokens and remove them when testing is complete.

## Reporting issues & vulnerabilities
If you discover a security issue in this project:
1. Do NOT exploit it.
2. Email the repository owner at: `<your-email@example.com>` with `Security issue` in the subject.
3. Include a clear description of the issue, steps to reproduce, and suggested fix (if known).
4. If you prefer, open a private GitHub issue or contact via the method listed in `README.md`.

## Disclosure timeline
We will acknowledge valid reports within 7 days and aim to publish a fix within 30 days depending on severity.

## Contact
Owner: Deepika  
Email: `<your-email@example.com>` (replace with a monitored email)
